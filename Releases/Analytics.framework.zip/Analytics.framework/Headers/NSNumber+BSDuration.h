//
//  NSNumber+BSDuration
//  Bugsnag Notifier
//
//  Created by Simon Maynard on 12/7/12.
//
//

#import <Foundation/Foundation.h>

@interface NSNumber (BSDuration)
- (NSString *) durationString;
@end
