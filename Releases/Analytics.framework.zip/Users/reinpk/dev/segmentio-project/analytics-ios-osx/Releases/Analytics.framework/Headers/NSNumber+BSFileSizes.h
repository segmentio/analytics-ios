//
//  NSNumber+BSFileSizes.h
//  Bugsnag Notifier
//
//  Created by Simon Maynard on 12/6/12.
//
//

#import <Foundation/Foundation.h>

@interface NSNumber (BSFileSizes)
- (NSString *)fileSize;
@end
